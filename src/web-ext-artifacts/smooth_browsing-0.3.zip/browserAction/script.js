$(function() { AOS.init(); }); // AOS.js reveal on scroll must te GLOBAL
